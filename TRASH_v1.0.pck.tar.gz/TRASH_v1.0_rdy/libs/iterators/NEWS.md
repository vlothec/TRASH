## 1.0.14

- Maintainer change (Folashade Daniel; fdaniel@microsoft.com).

## 1.0.13

- Maintainer change (Michelle Wallig; Michelle.Wallig@microsoft.com).

## 1.0.12

- Exported makeIwrapper function; request of Bill Venables.
- Exported `isample` iterator maker function.
