

revCompString = function(DNAstr) 
{
  return(toupper(toString(reverseComplement(DNAString(DNAstr)))))
}
